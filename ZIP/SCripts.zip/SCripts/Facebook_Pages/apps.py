from django.apps import AppConfig


class FacebookPagesConfig(AppConfig):
    name = 'Facebook_Pages'
