from django.contrib import admin
from Facebook_Pages.models import Facebook_Category, FacebookDatapages
# Register your models here.
admin.site.register(Facebook_Category)
admin.site.register(FacebookDatapages)